import logging
import asyncio, io, base64, mimetypes, os
from pathlib import Path
import re
from PIL import Image
from apps.proxy.hls_proxy.server import ProxyServer
from apps.proxy.ts_proxy.channel_status import ChannelStatus
from playwright.async_api import async_playwright
import math

class ActiveStreamImgGen:
  """
  Generates a 1920x1080 JPG image of active streams using Playwright and Pillow.
  """

  DEFAULT_TITLE = "Sorry, this channel is unavailable."
  DEFAULT_DESCRIPTION = "While this channel is not currently active, here are some other channels you can watch."

  DEFAULT_HTML_COLS = 2  # fixed 2-column grid
  DEFAULT_OUT_FILE = "too_many_streams.jpg"

  def __init__(self, title:str = DEFAULT_TITLE, description:str = DEFAULT_DESCRIPTION, out_path: str = DEFAULT_OUT_FILE, html_cols: int = DEFAULT_HTML_COLS):
    self.title = title
    self.description = description
    self.out_path = out_path
    self.html_cols = html_cols
    self.active_streams:list[tuple[str,str,str]] = []

    self.logger = logging.getLogger('plugins.too_many_streams.ActiveStreamImgGen')
    self.logger.setLevel(logging.DEBUG)


  def get_active_streams(self) -> list[tuple[str,str,str]]:
    """
    Placeholder method to fetch active streams.
    Returns:
      List of tuples: Each tuple contains (channel_number, icon_url, channel_name).
    """
    # This should be replaced with actual logic to fetch active streams
    self.active_streams = [
        ("#1000", 'https://res.cloudinary.com/dfv27amnl/image/upload/v1757501880/nflmiamidolphins_szqe6e.png', "Cartoon Network"),
        ("#1050", "https://res.cloudinary.com/dfv27amnl/image/upload/v1757501979/cache_htcrok.png", "Disney+"),
        ("#9000", "https://res.cloudinary.com/dfv27amnl/image/upload/v1757501897/cache_i1cnyu.png", "Example"),
        ("#1000", 'https://res.cloudinary.com/dfv27amnl/image/upload/v1757501880/nflmiamidolphins_szqe6e.png', "Cartoon Network"),
        ("#1050", "https://res.cloudinary.com/dfv27amnl/image/upload/v1757501979/cache_htcrok.png", "Disney+"),

    ]
    # Below code is from Dispatcharr\apps\proxy\ts_proxy\views.py
    proxy_server = ProxyServer.get_instance()
    channel_pattern = "ts_proxy:channel:*:metadata"
    all_channels = []

    # Extract channel IDs from keys
    cursor = 0
    while True:
        cursor, keys = proxy_server.redis_client.scan(
            cursor, match=channel_pattern
        )
        for key in keys:
            channel_id_match = re.search(
                r"ts_proxy:channel:(.*):metadata", key.decode("utf-8")
            )
            if channel_id_match:
                ch_id = channel_id_match.group(1)
                channel_info = ChannelStatus.get_basic_channel_info(ch_id)
                self.logger.debug(f"Channel ID DATA: {ch_id}, Info: {channel_info}")
                if channel_info:
                    all_channels.append(channel_info)

        if cursor == 0:
            break
  

    return self.active_streams

  def file_to_data_uri(self, path: str) -> str:
      """
      Converts a local file to a data URI for embedding in HTML.
      Args:
          path (str): Path to the local file.
      Returns:
        str: Data URI of the file.
      """
      p = Path(path).expanduser().resolve()
      if not p.exists():
          # fallback 1x1 gray square
          png = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
                b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\x0cIDATx\x9cc\xf8\xcf"
                b"\xc0\x00\x00\x03\x01\x01\x00\x18\xdd\x8d\x1d\x00\x00\x00\x00IEND\xaeB`\x82")
          b64 = base64.b64encode(png).decode()
          return f"data:image/png;base64,{b64}"
      mime, _ = mimetypes.guess_type(p.as_posix())
      mime = mime or "image/png"
      with open(p, "rb") as f:
          b64 = base64.b64encode(f.read()).decode()
      return f"data:{mime};base64,{b64}"



  def html_doc(self) -> str:
      """
      Generates the full HTML document for the channel grid.
      Returns:
        str: Complete HTML document as a string.
      """
      rows_count = len(self.active_streams)
      grid_rows = math.ceil(rows_count / self.html_cols)

      style = f"""
      <style>
        /* Full-HD canvas */
        html, body {{
          width:1920px; height:1080px; margin:0; background:#fff; color:#111;
          font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        }}

        /* Center whole block on the canvas */
        body {{
          display:flex; justify-content:center; align-items:center;
        }}

        .wrap {{
          width: 92%;
          max-width: 1680px;
          text-align: center;
        }}

        h1 {{
          font-size: clamp(36px, 5vh, 64px);
          margin: 0 0 12px;
        }}
        .desc {{
          width: 82%;
          margin: 0 auto 20px auto;
          font-size: clamp(16px, 2.2vh, 28px);
          line-height: 1.45;
          color: #333;
        }}

        :root {{
          --cols: {self.html_cols};
          --rows: {grid_rows};
          --grid-vh: 70vh; /* vertical space target for the grid area (static page) */
        }}

        .grid {{
          display: grid;
          grid-template-columns: repeat(var(--cols), 1fr);
          /* allow rows to grow if text wraps */
          grid-auto-rows: minmax(110px, auto);
          gap: 14px 18px; /* row gap, col gap */
          align-items: stretch;
          justify-items: stretch;
          margin: 0 auto;
          width: 100%;
        }}

        .card {{
          background: #ffffff;
          border: 1px solid #e6e9ef;
          border-radius: 16px;
          box-shadow: 0 1px 2px rgba(16,24,40,0.04);
          padding: clamp(10px, 1.6vh, 18px) clamp(14px, 2vw, 26px);
          display: flex;
          align-items: center;
          justify-content: flex-start;
          gap: clamp(12px, 2vw, 26px);
        }}

        .chan {{
          flex: 0 0 auto;
          font-weight: 600;
          font-size: clamp(16px, 2vh, 26px);
          padding: 6px 14px;
          border-radius: 999px;
          background: #eef2ff;
          color: #1d4ed8;
          border: 1px solid #dbe5ff;
          white-space: nowrap;
        }}

        /* Fixed 200x200 logo box */
        .icon {{
          flex: 0 0 auto;
          width: 200px;
          height: 200px;
          display: flex;
          align-items: center;   /* center the image vertically */
          justify-content: center; /* center the image horizontally */
          overflow: hidden;
          border-radius: 12px;
          background: #fff;
          border: 1px solid #e6e9ef;
        }}

        /* Image fills the box but keeps aspect ratio */
        .icon img {{
          width: 100%;
          height: 100%;
          object-fit: contain;   /* no stretching; letterboxes as needed */
          display: block;
          /* optional: make tiny logos less blurry or crisper */
          image-rendering: -webkit-optimize-contrast;
          image-rendering: crisp-edges;
          image-rendering: pixelated;
        }}

        /* NAME WRAPS: allow multi-line wrapping within remaining space */
        .name {{
          flex: 1 1 auto;
          text-align: left;
          font-size: clamp(18px, 2.2vh, 30px);
          font-weight: 500;
          color: #0f172a;
          line-height: 1.25;
          /* allow wrapping */
          white-space: normal;
          word-break: break-word;
          overflow-wrap: anywhere;
        }}
      </style>
      """

      # Build cards (embed local files as data: URIs to avoid path issues)
      cards = []
      for num, icon, name in self.active_streams:
          src = icon if icon.startswith(("http://","https://","data:")) else self.file_to_data_uri(icon)
          cards.append(
              f"""<div class="card">
                    <div class="chan">{num}</div>
                    <div class="icon"><img src="{src}" alt="icon"></div>
                    <div class="name">{name}</div>
                  </div>"""
          )

      return f"""<!doctype html><html><head><meta charset="utf-8">{style}</head>
      <body>
        <div class="wrap">
          <h1>{self.title}</h1>
          <div class="desc">{self.description}</div>

          <div class="grid">
            {''.join(cards)}
          </div>
        </div>
      </body></html>"""



  async def generate(self):
      async with async_playwright() as p:
          browser = await p.chromium.launch()
          ctx = await browser.new_context(viewport={"width":1920,"height":1080}, device_scale_factor=1.0)
          page = await ctx.new_page()
          await page.set_content(self.html_doc(), wait_until="load")

          # Wait for all images to finish loading
          await page.wait_for_function("""
              () => Array.from(document.images).every(img => img.complete && img.naturalWidth > 0)
          """, timeout=10000)

          png_bytes = await page.screenshot(type="png", full_page=False)
          await ctx.close(); await browser.close()

      # PNG -> JPG (white background)
      im = Image.open(io.BytesIO(png_bytes))
      bg = Image.new("RGB", im.size, (255,255,255))
      if im.mode in ("RGBA","LA"): 
        bg.paste(im, mask=im.split()[-1])
      else: 
          bg.paste(im)

      bg.save(self.out_path, "JPEG", quality=92, optimize=True)
      print(f"Wrote {self.out_path}")


if __name__ == "__main__":
    asig = ActiveStreamImgGen('too_many_streams.jpg', 3)
    asyncio.run(asig.generate())
