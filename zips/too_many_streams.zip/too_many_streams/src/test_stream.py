#!/usr/bin/env python3
import os, shutil, subprocess, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Optional

def stream_still_mpegts_http(
        image_path: str,
        on_client_start: Optional[Callable[[], Optional[str]]] = None,
        host: str = "127.0.0.1",
        port: int = 8081,
    ) -> None:
        """
        Serve an infinite MPEG-TS stream over HTTP. For each client connection, an optional
        callback `on_client_start()` is invoked BEFORE ffmpeg starts. If the callback returns
        a string path, that image is used for this client; if it returns None, `image_path`
        is used.

        Open in VLC: Media -> Open Network Stream -> http://<host>:<port>/stream.ts
        (Default: http://127.0.0.1:8081/stream.ts)
        """

        def ffmpeg_or_die():
            exe = shutil.which("ffmpeg")
            if not exe:
                sys.exit("ERROR: ffmpeg not found in PATH. Install ffmpeg and try again.")
            return exe

        if not os.path.exists(image_path):
            sys.exit(f"ERROR: Image not found: {image_path}")

        ffmpeg_bin = ffmpeg_or_die()

        # Encoding defaults tuned for compatibility + quick startup for a still image
        fps = 2
        width = 1280
        v_bitrate = "800k"
        a_bitrate = "96k"
        muxrate   = "900k"
        bufsize   = "1600k"

        # Pre-detect encoders once (best-effort)
        def encoder_available(name: str) -> bool:
            try:
                out = subprocess.check_output([ffmpeg_bin, "-v", "0", "-hide_banner", "-encoders"], text=True)
                return f" {name} " in out
            except Exception:
                return False

        use_h264 = encoder_available("libx264")
        use_aac  = encoder_available("aac")

        # Build the command for a given image
        def make_ffmpeg_cmd(img: str, stream_ts:str):

            in_args = [
                "-loop","1","-framerate",str(fps),"-i",img,
                "-f","lavfi","-i","anullsrc=r=48000:cl=stereo",
                "-c:v","libx264","-preset","ultrafast","-tune","stillimage","-r",str(fps),"-g",str(fps),"-keyint_min",str(fps),
                "-b:v",v_bitrate,"-maxrate",v_bitrate,"-minrate",v_bitrate,"-bufsize",bufsize,
                "-c:a","aac" if use_aac else "mp2","-b:a",a_bitrate,
                "-muxrate",muxrate,"-fflags","+genpts", "-mpegts_flags", "+resend_headers+initial_discontinuity", "-t", "10", "-f","mpegts", stream_ts
            ]

            # Return the full command
            return [ffmpeg_bin, *in_args]


        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"
            def do_GET(self):
                if self.path not in ("/", "/stream.ts"):
                    self.send_response(404)
                    self.end_headers()
                    self.wfile.write(b"Not found")
                    return

                # Pick image for THIS client
                chosen_img = None
                if on_client_start:
                    try:
                        chosen_img = on_client_start()
                    except Exception as e:
                        # Don't crash the server if the callback fails
                        print(f"[on_client_start] error: {e}", file=sys.stderr)
                if not chosen_img:
                    chosen_img = image_path
                print(f"T[HTTP] Client {self.client_address} using image: {chosen_img}")
                if not os.path.exists(chosen_img):
                    self.send_response(404)
                    self.end_headers()
                    self.wfile.write(b"Image not found")
                    return



                print(f"[HTTP] Client {self.client_address} starting stream from: {chosen_img}")
                # Send headers first so VLC starts reading
                self.send_response(200)
                # self.send_header("Content-Type", "video/MP2T")
                self.send_header("Content-Type", "video/mp2t")
                # self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                # self.send_header("Cache-Control", "no-cache")
                # self.send_header("Pragma", "no-cache")
                self.send_header("Connection", "close")
                self.end_headers()
                # Start ffmpeg for this client
                stream_ts = os.path.join(os.path.dirname(__file__), "no_streams.ts")
                if os.path.exists(stream_ts):
                    os.remove(stream_ts)
                cmd = make_ffmpeg_cmd(chosen_img, stream_ts)
                print(f"Running ffmpeg command: {' '.join(cmd)}")
                # # Generate the stream
                gen_ts = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                gen_ts.wait()  # wait for process to complete
                if gen_ts.returncode != 0:
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(b"Failed to generate stream")
                    return
                else:
                    gen_ts.terminate()
                if not os.path.exists(stream_ts):
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(b"Failed to generate stream")
                    return
                try:
                    with open(stream_ts, 'rb') as f:
                        while True:
                            # CHUNK = 1316 * 32  # bigger writes help downstream
                            CHUNK = 1316 * 1  # bigger writes help downstream
                            buf = f.read(CHUNK)
                            if not buf:
                                break
                            try:
                                self.wfile.write(buf)
                                # cnt += 1
                                # if (cnt & 0x03) == 0:   # flush every ~4 writes
                                # self.wfile.flush()
                            except Exception as e:
                                print(f"TMS ERROR: [HTTP] Client {self.client_address} stream error: {e}", file=sys.stderr)
                                
                except Exception as e:
                    print(f"TMS ERROR: [HTTP] Client {self.client_address} stream error: {e}", file=sys.stderr)
                print(f"TMS ERROR: [HTTP] Client {self.client_address} disconnected")

            def log_message(self, fmt, *args):
                # Quieter server logs
                return

        httpd = ThreadingHTTPServer((host, port), Handler)
        print(f"HTTP MPEG-TS server listening on http://{host}:{port}/stream.ts")
        print("Open in VLC: Media -> Open Network Stream -> http://127.0.0.1:8081/stream.ts")
        print("Press Ctrl+C to stop.\n")

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopping server…")
            # shutdown() from a non-main thread is safe; here we're in main.
            httpd.shutdown()
            httpd.server_close()

import itertools
images = itertools.cycle([
    r"C:\Users\james\Documents\GitHub\Dispatcharr_Too_Many_Streams\src\no_streams.jpg",
    r"C:\Users\james\Documents\GitHub\Dispatcharr_Too_Many_Streams\src\no_streams2.jpg",
    r"C:\Users\james\Documents\GitHub\Dispatcharr_Too_Many_Streams\src\no_streams3.jpg",
])

def on_join():
    # do logging, analytics, DB lookups, etc.
    print(">>> New client connected; rotating image…")
    return next(images)  # return the image to use for THIS client

stream_still_mpegts_http(r"C:\Users\james\Documents\GitHub\Dispatcharr_Too_Many_Streams\src\no_streams.jpg", on_client_start=on_join)